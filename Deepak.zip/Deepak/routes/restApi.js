var express = require('express');
var router = express.Router();

let userService = require('../service/userService')

router.post('/register', function(req, res) {

    let name = req.body.name;
    let password = req.body.password;
    let email = req.body.email;

    let errorMessage = "";
    let hasError = false

    if(name == "" || typeof name == "undefined" || name == null){
        errorMessage = errorMessage.concat("No Name")
        hasError = true
    }

    if(password == "" || typeof password == "undefined" || password == null){
        errorMessage = errorMessage.concat("No Password")
        hasError = true
    }

    if(email == "" || typeof email == "undefined" || email == null){
        errorMessage = errorMessage.concat("No Name")
        hasError = true
    }

    if(hasError){
        res.statusCode = 205;
        res.statusMessage = "Missing Fields"
        res.send({"errorMessage": errorMessage, "daw": "dawda d"});
        res.end();
    }else{
        let userPresentPromise = userService.getUserOnEmail(email);

        userPresentPromise.then((resp) => {
            if(resp != null){
                res.statusCode = 203;
                res.statusMessage = "User Already Present"
                res.send({"errorMessage": "User Already Present"});
                res.end();
            }else{
                let saveUserPromise = userService.saveUser(name, email, password);
                saveUserPromise.then((resp) => {
                    res.send({"user": resp});
                    res.end();
                }).catch((err) => {
                    res.statusCode = 500;
                    res.statusMessage = "Internal Server Error"
                    res.send({"error": err});
                    res.end();
                })
            }
        }).catch((err) => {
            console.error("Error in getUserOnEmail")
        })


    }

});


router.post('/authencateUser', (req, res) => {
    let password = req.body.password;
    let email = req.body.email;
    let errorMessage = "";
    let hasError = false

    if(password == "" || typeof password == "undefined" || password == null){
        errorMessage = errorMessage.concat("No Password")
        hasError = true
    }

    if(email == "" || typeof email == "undefined" || email == null){
        errorMessage = errorMessage.concat("No Name")
        hasError = true
    }

    if(hasError){
        res.statusCode = 205;
        res.statusMessage = "Missing Fields"
        res.send({"errorMessage": errorMessage, "daw": "dawda d"});
        res.end();
    }else{
        let userPresentPromise = userService.authencateUser(email, password);

        userPresentPromise.then((resp) => {
            if(resp){
                res.statusCode = 200;
                res.statusMessage = "Valid User";
                res.send({"message": "valid User"});
                res.end();
            }else{
                res.statusCode = 206;
                res.statusMessage = "Username and Password Does't Match"
                res.send({"message": "Username and Password Does't Match"});
                res.end();
            }
        }).catch((err) => {
            console.error(err);
        })

    }
});

module.exports = router;
