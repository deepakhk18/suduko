CREATE SCHEMA `hope_research_group_requirement` ;

CREATE TABLE `hope_research_group_requirement`.`users` (
  `id` INT NOT NULL,
  `email` VARCHAR(100) NULL,
  `password` VARCHAR(100) NULL,
  `name` VARCHAR(100) NULL,
  PRIMARY KEY (`id`));

  ALTER TABLE `hope_research_group_requirement`.`users`
  CHANGE COLUMN `id` `id` INT(11) NOT NULL AUTO_INCREMENT ;

