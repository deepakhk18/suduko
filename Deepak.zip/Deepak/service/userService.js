const bcrypt = require('bcryptjs');
const userDao = require('../persistance/userDao');
let sequlieseInitilise = require('../Model/sequilizeinitialize');
let userModel = sequlieseInitilise.usersModel;


module.exports.saveUser = (name, email, password) => {
    return new Promise((resolve, reject) => {
        bcrypt.genSalt(10, function(err, salt) {
            bcrypt.hash(password, salt, function(err, hash) {
                var newUser = userModel.build({
                    id: null,
                    name: name,
                    email: email,
                    password: hash
                })

                let saveUserPromise = userDao.saveUser(newUser);

                saveUserPromise.then((resp) => {
                    resolve(resp);
                }).catch((err) => {
                    console.error("Error in saveUser", err);
                    reject(err);
                })
            })
        })
    });
};

module.exports.getUserOnEmail = (email) => {
    return new Promise((resolve, reject) => {
        let userPromise = userDao.getUserByemail(email);
        userPromise.then((user) => {
            resolve(user);
        }).catch((err) => {
            console.error("Error in getUserOnEmail", err);
            reject(err);
        })
    })
};

module.exports.authencateUser = (email, candidatePassword) => {
    return new Promise((resolve, reject) => {
        let userPromise = userDao.getUserByemail(email);

        userPromise.then((user) => {
            if (user) {
                bcrypt.compare(candidatePassword, user.password, function(err, isMatch) {
                    if (err){
                        reject(err);
                    }
                    resolve(isMatch)
                });
            } else {
                resolve(false)
            }
        }).catch((err) => {
            console.error("Error in authencateUser", err);
            reject(err);
        });
    })
};