var dbConfig = require('../config/databaseconfig');

var Sequelize = require('sequelize'),
    sequelize = new Sequelize(dbConfig.db_database, dbConfig.db_username, dbConfig.db_password, {
        dialect: "mysql",
        port: dbConfig.db_port,
        host: dbConfig.host,
        logging:false,
        pool: { idle: 30000,
            min: 20,
            max: 30
        }
    });
// logging:false


sequelize
    .authenticate()
    .then(function(err) {
        console.log('Connection has been established successfully.');
    }, function(err) {
        console.log('Unable to connect to the database:', err);
    });

// load models
var models = [
    'usersModel'
];
models.forEach(function(model) {
    module.exports[model] = sequelize.import(__dirname + '/' + model);
});


// export connection
module.exports.sequelize = sequelize;
