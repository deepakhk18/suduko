module.exports = {
    'host': 'localhost',
    'db_username': 'root',
    'db_password': 'santhosh@123',
    'db_port': 3306,
    'db_minpool': 0,
    'db_maxpool': 10,
    'db_connectionLimit': 10,
    'db_database': 'hope_research_group_requirement'
}