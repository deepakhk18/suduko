var sequilizeinitialize = require('../Model/sequilizeinitialize');

var sequelize = sequilizeinitialize.sequelize;

module.exports.getUserByemail = (email) => {

    return new Promise((resolve, reject) => {
        var query = 'select * from users where email=:email';

        return sequelize.transaction(function(t) {
            return sequelize.query(query, {replacements: {"email": email},  transaction: t }).spread(function(user, metadata) {
                if (user == null || user.length == 0) {
                    resolve(null)
                } else {
                    resolve(user[0]);
                }
            }).catch(function(err) {
                console.error("Error in getUserByemail", err);
                reject(err);
            })
        })
    })
};

module.exports.saveUser = (userRecord) => {
    return new Promise((resolve, reject) => {
        return sequelize.transaction(function(t) {
            return userRecord.save({ transaction: t }).then(function(newUser) {
                resolve(newUser.dataValues);
            }).catch(function(err) {
                reject(err);
            })
        })
    })
};